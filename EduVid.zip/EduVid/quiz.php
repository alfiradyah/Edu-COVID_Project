<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta content="" name="description" />
    <meta content="" name="keywords" />

    <link href="assets/img/icon.png" rel="icon" />
    <link href="assets/img/icon.png" rel="apple-touch-icon" />

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous" />

    <link rel="stylesheet" href="./css/inputnama.css" />

    <!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
  <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
  <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
  <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
  <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
  <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/perfect-scrollbar/perfect-scrollbar.css">
  <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="css/util.css">
    <link rel="stylesheet" type="text/css" href="css/main2.css">
  <!--===============================================================================================-->

    <title>Kuis Pemahaman COVID-19</title>
  </head>

  <body>
    <nav class="fixed-top navbar navbar-light bg-light">
      <div class="container-fluid">
        <a class="navbar-brand" href="#">
          <img src="./img/eduvid.png" alt="" width="120" height="38" class="d-inline-block align-text-center" />
        </a>
        <div class="d-flex">
          <a class="nav-link" href="index.php">BERANDA</a>
          <a class="nav-link" href="cegah-covid.html">CEGAH COVID-19</a>
          <a class="nav-link" href="data-covid.html">DATA COVID-19</a>
          <a class="nav-link" href="inputnama.html">KUIS</a>
          <a class="nav-link" href="login.php"> LOG IN</a>
        </div>
      </div>
    </nav>

    <center>
      <div class="card" style="width: 58rem; height: 500px">
        <div class="card-body">
          <h5 class="card-title"></h5>
          <h3 class="card-subtitle mb-2 text-muted">Kuis Seputar COVID-19</h3>
          <br />
          <div id="quiz"></div>
          <div class="btn" id="next"><a href="#">Next</a></div>
          <div class="btn" id="prev"><a href="#">Prev</a></div>
          <div class="btn" id="start"><a href="#">Mulai Lagi ?</a></div>
        
          <div class="limiter" id="skor">
            <div class="container-table100">
              <div class="wrap-table100">
                <div class="table100 ver1 m-b-110">
                  <div class="table100-head">
                    <table>
                      <thead>
                        <tr class="row100 head">
                          <th class="cell100 column1">Nama</th>
                          <th class="cell100 column2">Score</th>
                        </tr>
                      </thead>
                    </table>
                  </div>
        
                  <div class="table100-body js-pscroll">
                    <table>
                      <tbody>

                      <?php
                    $con=mysqli_connect("localhost","root","","eduvid");
                    // Check connection
                    if (mysqli_connect_errno())
                    {
                    echo "Failed to connect to MySQL: " . mysqli_connect_error();
                    }

                    $result = mysqli_query($con,"SELECT * FROM data_score");

                    while($row = mysqli_fetch_array($result)) {
                      $id_guest = $row['id_guest'];
                      $nama_guest = $row['nama_guest'];
                      $score_guest = $row['score_guest'];
                    }

                    // Card Sembuh
                     // Card Positif
                     echo '<tr class="row100 body">
                     <td class="cell100 column1">' .  $nama_guest . '</td>';
                     echo '<td class="cell100 column2" id="score">' .  $score_guest . '</td></tr>';
                     

                  

                    mysqli_close($con);
              ?>
                       
        
                        
                      </tbody>
                    </table>
                  </div>

                </div>
                
                
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </center>

    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script type="text/javascript" src="questions.json"></script>
    <script type="text/javascript" src="jsquiz.js"></script>
    <script src="js/index.js"></script>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
    -->

    <!--===============================================================================================-->	
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
  <!--===============================================================================================-->
    <script src="vendor/bootstrap/js/popper.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
  <!--===============================================================================================-->
    <script src="vendor/select2/select2.min.js"></script>
  <!--===============================================================================================-->
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <script>
      $('.js-pscroll').each(function(){
        var ps = new PerfectScrollbar(this);
  
        $(window).on('resize', function(){
          ps.update();
        })
      });
        
      var score = document.getElementById('score');
      score.innerHTML
    </script>
  <!--===============================================================================================-->
    <script src="js/score.js"></script>

  </body>
</html>
