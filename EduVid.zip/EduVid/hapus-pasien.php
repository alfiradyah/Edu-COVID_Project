<?php
// include database connection file
include_once("koneksi.php");

// Get id from URL to delete that user
$id = $_GET['id'];

$sql = mysqli_query($db, "SELECT * FROM data_covid WHERE id_pasien=$id");
$data = $sql->fetch_assoc();
$id_pasien = $data['id_pasien'];
$nama_pasien = $data['nama_pasien'];


// Delete user row from table based on given id
$result = mysqli_query($db, "DELETE FROM data_covid WHERE id_pasien=$id");
  if($result){
  	echo "<script>alert($id_pasien)</script>";
    echo "<script>alert($nama_pasien)</script>";
    header("Location:data-covid.php?alert=berhasil");
  }else{
    echo "Maaf, Terjadi kesalahan saat menghapus pasien di database.";
    echo "<br><a href='edit-data-covid.php?alert=kesalahan'>Kembali Ke Data Covid</a>";
  }


?>