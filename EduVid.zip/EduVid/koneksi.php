<?php
   $hostname  = "localhost";
   $nama  = "root";
   $password  = "";
   $dbname  = "eduvid";
   $db = new mysqli($hostname, $nama, $password, $dbname);
