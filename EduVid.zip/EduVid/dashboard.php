<?php
//logout
session_start();
session_destroy();

// arahkan ke halaman login.php 
if (isset($_POST['keluar'])) {
  header("location: login.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <!-- Bootstrap CSS -->
  <link href="./css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous" />
  <!-- CSS Style -->
  <link rel="stylesheet" href="./css/style.css" />
  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.gstatic.com" />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet" />

  <title>🏠 Dashboard</title>
</head>

<body>
  <div class="container-fluid">
    <div class="row">
      <!-- fixed -->
      <div class="position-fixed top-0 start-0 col-3 text-center container-menu" style="z-index: 1;">
        <div>
          <!-- Logo Eduvid -->
          <img class="mt-4" src="./assets/img/logo-eduvid.svg" alt="Logo Eduvid" />
          <!-- Wrapper menu -->
          <div class="px-4 mt-5" action="" method="POST">
            <!-- Menu Dashboard -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 menu selected">
              <img class="img-menu" src="./assets/img/i-dashboard-white.svg" alt="icon dashboard" />
              <p class="my-auto ms-3 gray-color title-menu title-menu-active">Dashboard</p>
            </a>
            <!-- Menu Data Covid Active -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 menu" href="data-covid.php">
              <img class="img-menu" src="./assets/img/i-covid-gray.svg" alt="icon dashboard" />
              <p class="my-auto ms-3 gray-color">
                Data Covid
              </p>
            </a>
            <!-- Menu User -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 menu" href="data-user.php">
              <img class="img-menu" src="./assets/img/i-user-gray.svg" alt="icon dashboard" />
              <p class="my-auto ms-3 gray-color title-menu">Data User</p>
            </a>
            <!-- Menu Kembali -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 to-home">
              <img class="img-menu" src="./assets/img/i-back-blue.svg" alt="icon dashboard" />
              <button class="my-auto ms-3 btn" name="keluar" style="color: #0085ff">Log Out</button>
            </a>
          </div>
        </div>
      </div>
      <!-- Menu -->
      <div class="col-3 text-center container-menu">
        <div>
          <!-- Logo Eduvid -->
          <img class="mt-4" src="./assets/img/logo-eduvid.svg" alt="Logo Eduvid" />
          <!-- Wrapper menu -->
          <div class="px-4 mt-5">
            <!-- Menu Dashboard -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 menu selected " href="dashboard.php">
              <img class="img-menu" src="./assets/img/i-dashboard-white.svg" alt="icon dashboard" />
              <p class="my-auto ms-3 gray-color title-menu title-menu-active">Dashboard</p>
            </a>
            <!-- Menu Data Covid Active -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 menu" href="data-covid.php">
              <img class="img-menu" src="./assets/img/i-covid-gray.svg" alt="icon dashboard" />
              <p class="my-auto ms-3 gray-color">
                Data Covid
              </p>
            </a>
            <!-- Menu User -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 menu" href="data-user.php">
              <img class="img-menu" src="./assets/img/i-user-gray.svg" alt="icon dashboard" />
              <p class="my-auto ms-3 gray-color title-menu">Data User</p>
            </a>
            <!-- Menu Keluar -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 to-home">
              <img class="img-menu" src="./assets/img/i-back-blue.svg" alt="icon dashboard" />
              <button class="my-auto ms-3 btn" name="keluar" style="color: #0085ff">Log Out</button>
            </a>
          </div>
        </div>
      </div>
      <!-- Content -->
      <div class="col white-color px-5">
        <!-- Title -->
        <h1 class="title mt-4">🏠 Dashboard</h1>
        <div class="mt-4">
          <!-- Card summary -->
          <h5>Summary Data</h5>
          <hr class="divider" />
          <div class="mt-4 d-flex">

            <?php
            $con = mysqli_connect("localhost", "root", "", "eduvid");
            // Check connection
            if (mysqli_connect_errno()) {
              echo "Failed to connect to MySQL: " . mysqli_connect_error();
            }

            $result_user = mysqli_query($con, "SELECT * FROM data_user");
            $result_covid = mysqli_query($con, "SELECT * FROM data_covid");



            $count_user = 0;
            $count_covid = 0;


            while ($row = mysqli_fetch_array($result_user)) {

              $count_user++;
            }

            while ($row = mysqli_fetch_array($result_covid)) {

              $count_covid++;
            }

            // Card Positif
            echo '<div class="card-summary ps-3 pe-5 pt-3 me-3">
                    <h6 class="title-card">Total User</h6>';
            echo " <p class='count-data' style='color: #0085FF;'>" .  $count_user . "<span>user</span></p>";
            echo "</div>";

            // Card Sembuh
            echo "<div class='card-summary ps-3 pe-5 pt-3 me-3'>
                    <h6 class='title-card'>Total Data Covid</h6>";
            echo " <p class='count-data' style='color: #44A44E;'>" .  $count_covid . "<span>kasus</span></p>";
            echo "</div>";



            mysqli_close($con);
            ?>



          </div>
        </div>
        <div class="">
          <div class="mt-5 px-3 py-3 shadow rounded-3">
            <h5>Total User</h5>
            <hr class="divider" />
            <canvas id="chartTotalUser"></canvas>
          </div>
          <div class="mt-5 px-3 py-3 shadow rounded-3">
            <h5>Total Data Covid</h5>
            <hr class="divider" />
            <canvas id="totalDataCovid"></canvas>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Optional JavaScript; choose one of the two! -->

  <!-- Option 1: Bootstrap Bundle with Popper -->
  <script src="./js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous">
  </script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@3.3.2/dist/chart.min.js"></script>
  <script>
    showTotalUserChart();
    showTotalDataCovidChart();


    function showTotalUserChart() {
      // Setup
      const labels = [
        'Jan',
        'Feb',
        'Mar',
        'Apr',
        'May',
        'Jun',
        'Jul',
        'Agu',
        'Sep',
        'Okt',
        'Nov',
        'Des'
      ];
      const data = {
        labels: labels,
        datasets: [{
          label: 'Total User',
          backgroundColor: 'rgb(0, 133, 255)',
          data: [3, 12, 14, 21, 22, 28, 30, 32, 34, 40, 50, 52],
        }]
      };
      // Config
      const config = {
        type: 'bar',
        data,
        options: {}
      };
      var totalUserChart = new Chart(
        document.getElementById('chartTotalUser'),
        config
      );
    }

    function showTotalDataCovidChart() {
      // Setup
      const labels = [
        'Jan',
        'Feb',
        'Mar',
        'Apr',
        'May',
        'Jun',
        'Jul',
        'Agu',
        'Sep',
        'Okt',
        'Nov',
        'Des'
      ];
      const data = {
        labels: labels,
        datasets: [{
          label: 'Total Data Covid',
          backgroundColor: 'rgb(68, 164, 78)',
          data: [3, 12, 14, 21, 22, 28, 30, 32, 34, 40, 50, 52],
        }]
      };
      // Config
      const config = {
        type: 'bar',
        data,
        options: {}
      };
      var totalDataCovid = new Chart(
        document.getElementById('totalDataCovid'),
        config
      );
    }
  </script>

  <!-- Option 2: Separate Popper and Bootstrap JS -->
  <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
    -->
</body>

</html>