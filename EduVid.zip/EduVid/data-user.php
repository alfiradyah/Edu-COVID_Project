<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="./css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
  <!-- CSS Style -->
  <link rel="stylesheet" href="./css/style.css">
  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

  <title> Data Covid </title>
</head>

<body>
  <div class="container-fluid">
    <div class="row">
      <!-- fixed -->
      <div class="position-fixed top-0 start-0 col-3 text-center container-menu" style="z-index: 1;">
        <div>
          <!-- Logo Eduvid -->
          <img class="mt-4" src="./assets/img/logo-eduvid.svg" alt="Logo Eduvid">
          <!-- Wrapper menu -->
          <div class="px-4 mt-5">
            <!-- Menu Dashboard -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 menu" href="dashboard.php">
              <img class="img-menu" src="./assets/img/i-dashboard-gray.svg" alt="icon dashboard">
              <p class="my-auto ms-3 gray-color title-menu">Dashboard</p>
            </a>
            <!-- Menu Data Covid Active -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 menu" href="data-covid.php">
              <img class="img-menu" src="./assets/img/i-covid-gray.svg" alt="icon dashboard">
              <p class="my-auto ms-3 gray-color">Data Covid</p>
            </a>
            <!-- Menu User -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 menu selected">
              <img class="img-menu" src="./assets/img/i-user-white.svg" alt="icon dashboard">
              <p class="my-auto ms-3 gray-color title-menu-active">Data User</p>
            </a>
            <!-- Menu Kembali -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 to-home">
              <img class="img-menu" src="./assets/img/i-back-blue.svg" alt="icon dashboard">
              <p class="my-auto ms-3 gray-color title-menu" style="color: #0085FF;">Log Out</p>
            </a>
          </div>
        </div>
      </div>
      <!-- Menu -->
      <div class="col-3 text-center container-menu">
        <div>
          <!-- Logo Eduvid -->
          <img class="mt-4" src="./assets/img/logo-eduvid.svg" alt="Logo Eduvid">
          <!-- Wrapper menu -->
          <div class="px-4 mt-5">
            <!-- Menu Dashboard -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 menu" href="dashboard.php">
              <img class="img-menu" src="./assets/img/i-dashboard-gray.svg" alt="icon dashboard">
              <p class="my-auto ms-3 gray-color title-menu">Dashboard</p>
            </a>
            <!-- Menu Data Covid Active -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 menu" href="data-covid.php">
              <img class="img-menu" src="./assets/img/i-covid-gray.svg" alt="icon dashboard">
              <p class="my-auto ms-3 gray-color">Data Covid</p>
            </a>
            <!-- Menu User -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 menu selected" href="data-user.php">
              <img class="img-menu" src="./assets/img/i-user-white.svg" alt="icon dashboard">
              <p class="my-auto ms-3 gray-color title-menu-active">Data User</p>
            </a>
            <!-- Menu Kembali -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 to-home">
              <img class="img-menu" src="./assets/img/i-back-blue.svg" alt="icon dashboard">
              <p class="my-auto ms-3 gray-color title-menu" style="color: #0085FF;">Log Out</p>
            </a>
          </div>
        </div>
      </div>
      <!-- Content -->
      <div class="col-9 white-color px-5">
        <!-- Title -->
        <h1 class="title mt-4">Data User</h1>
        <div class="mt-4">
          <!-- Card summary-->
          <h5>Summary Data</h5>
          <hr class="divider">
          <div class="mt-4 d-flex">
            <?php
            $con = mysqli_connect("localhost", "root", "", "eduvid");
            // Check connection
            if (mysqli_connect_errno()) {
              echo "Failed to connect to MySQL: " . mysqli_connect_error();
            }

            $result = mysqli_query($con, "SELECT * FROM data_user");



            $count_user = 0;
            $count_admin = 0;
            $count_covidranger = 0;


            while ($row = mysqli_fetch_array($result)) {
              $status_pasien = $row['role_user'];

              $count_user++;


              if (strcasecmp($status_pasien, "Admin") == 0) {
                $count_admin++;
              }

              if (strcasecmp($status_pasien, "Covid Ranger") == 0) {
                $count_covidranger++;
              }
            }
            // Card Positif
            echo '<div class="card-summary ps-3 pe-5 pt-3 me-3">
                    <h6 class="title-card">Total User</h6>';
            echo " <p class='count-data' style='color: #0085FF;'>" .  $count_user . "<span>user</span></p>";
            echo "</div>";

            // Card Sembuh
            echo "<div class='card-summary ps-3 pe-5 pt-3 me-3'>
                    <h6 class='title-card'>Total Admin</h6>";
            echo " <p class='count-data' style='color: #44A44E;'>" .  $count_admin . "<span>user</span></p>";
            echo "</div>";

            // Card Meninggal
            echo "<div class='card-summary ps-3 pe-5 pt-3 me-3'>
                    <h6 class='title-card'>Total Covid Ranger</h6>";
            echo " <p class='count-data' style='color: #E42E2E;'>" .  $count_covidranger . "<span>user</span></p>";
            echo "</div>";

            mysqli_close($con);
            ?>
          </div>
          <!-- data user -->
          <div class="mt-5 d-flex justify-content-between align-items-center">
            <h5>Data User</h5>
            <form class="container-search" action="data-user.php" method="get">
              <input type="text" name="cari" class="input-search" id="" placeholder=<?php
                                                                                    if (isset($_GET['cari'])) {
                                                                                      $cari = $_GET['cari'];
                                                                                      echo "'Hasil pencarian : " . $cari . "'";
                                                                                    } else {
                                                                                      echo "'Cari'";
                                                                                    }
                                                                                    ?>>
              <input type="image" value="Cari" class="icon-search" src="assets/img/i-search-gray.svg" alt="">
            </form>
          </div>

          <hr class="divider">

          <?php
          $con = mysqli_connect("localhost", "root", "", "eduvid");
          // Check connection
          if (mysqli_connect_errno()) {
            echo "Failed to connect to MySQL: " . mysqli_connect_error();
          }

          if (isset($_GET['cari'])) {
            $cari = $_GET['cari'];
            $result = mysqli_query($con, "SELECT * FROM data_user WHERE nama_user LIKE '%" . $cari . "%'");
          } else {
            $result = mysqli_query($con, "SELECT * FROM data_user");
          }

          //$result = mysqli_query($con,"SELECT * FROM data_covid");

          echo '<div class="overflow-auto">
                  <table class="table table-hover">
                    <thead>
                      <tr class="table-head">
                        <th scope="col">ID</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Jenis Kelamin</th>
                        <th scope="col">Tanggal lahir</th>
                        <th scope="col">Nomor Telepon</th>
                        <th scope="col">Email</th>
                        <th scope="col">Password</th>
                        <th scope="col">Role</th>
                        <th scope="col">Action</th>
                      </tr>
                    </thead>
                    <tbody>';

          while ($row = mysqli_fetch_array($result)) {
            echo "<tr>";
            echo "<td>" . $row['id_user'] . "</td>";
            echo "<td>" . $row['nama_user'] . "</td>";
            echo "<td>" . $row['jk_user'] . "</td>";
            echo "<td>" . $row['tgl_user'] . "</td>";
            echo "<td>" . $row['notelp_user'] . "</td>";
            echo "<td>" . $row['email_user'] . "</td>";
            echo "<td>" . $row['password_user'] . "</td>";
            $role_user = $row['role_user'];
            if (strcasecmp($role_user, "Admin") == 0) {
              echo "<td> <div class='px-3 px-2 rounded-3 text-center' style='background-color: #58FE3D; color: #FFFFFF;'> " . $row['role_user'] . "</div> </td>";
            }

            if (strcasecmp($role_user, "Covid Ranger") == 0) {
              echo "<td> <div class='px-3 px-2 rounded-3 text-center' style='background-color: #FE3D3D; color: #FFFFFF;'> " . $row['role_user'] . "</div> </td>";
            }

            echo "<td align = 'center'> <a href='edit-data-user.php?id=$row[id_user]' onclick = '' class='btn d-flex align-items-center justify-content-center btn-action rounded-3' style='background-color: #0085FF; color: #f0f0f0;'><img class='me-1' src='./assets/img/i-edit-white.svg' alt=''>Edit</a></td>";

            echo "<td align = 'center'> <a href= 'javascript:hapusData(" . $row['id_user'] . ")' onclick='return confirm('Yakin Hapus ?')' class='btn d-flex align-items-center justify-content-center btn-action rounded-3' style='background-color: #E42E2E; color: #f0f0f0;'><img class='me-1' src='./assets/img/i-delete-white.svg' alt=''>Hapus</a></td>";
            echo "</tr>";
          }
          echo "</tbody>
                  </table>
                </div>";

          mysqli_close($con);
          ?>

          <script language="JavaScript" type="text/javascript">
            function hapusData(id) {
              if (confirm("Apakah anda yakin akan menghapus data ini?")) {
                window.location.href = 'hapus-user.php?id=' + id;
              }
            }
          </script>


        </div>
      </div>
    </div>
  </div>

  <!-- Optional JavaScript; choose one of the two! -->

  <!-- Option 1: Bootstrap Bundle with Popper -->
  <script src="./js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

  <!-- Option 2: Separate Popper and Bootstrap JS -->
  <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
    -->
</body>

</html>