<?php
include 'koneksi.php';

session_start();

//Kondisi match
if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $password = md5($_POST['password']);

    //cek data user & pasword
    $sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
    $result = mysqli_query($db, $sql);
    $num = mysqli_num_rows($result);

    //kondisi kalo udh ada datanya
    if ($num > 0) {
        header("Location: dashboard.php"); //masuk ke admin
    } else {
        header("Location: login.php");
        echo "salah";
    }
}
?>

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

    <link href="./css/log-reg.css" type="text/css" rel="stylesheet">
    <title>Login Form EduCOVID</title>
</head>

<body>
    <section class="login py-5 bg-light">
        <div class="container">
            <div class="row g-0">
                <div class="col-lg-7 text-center py-5">
                    <h1>Welcome to Edu-COVID</h1>
                    <h4 class="py-3">Please Login to Explore More!</h4>
                    <form action="" method="POST" style="margin-top: 70px;">
                        <!-- <div class="form-row py-2 pt-5">
                            <div class="selectWrapper">
                                <select name="user" class="selectBox" required="">
                                    <option value="">-- Who Are You? --</option>
                                    <option value="admin">Admin</option>
                                    <option value="doctor">Covid Ranger</option>
                                </select>
                            </div>
                        </div> -->
                        <div class="form-row py-2">
                            <div class="offset-1 col-lg-10">
                                <input type="text" name="email" placeholder="Email" class="input" required>
                            </div>
                        </div>
                        <div class="form-row py-2">
                            <div class="offset-1 col-lg-10">
                                <input type="password" name="password" placeholder="Password" class="input" required>
                            </div>
                        </div>
                        <button class="btn" name="submit">Login</button>
                        <div class="py-2">
                            <p>Don't have an account? <a href="register.php">Register Here</a></p>
                        </div>
                    </form>
                </div>
                <div class="col-lg-5">
                    <img src="img/wearing-mask.png" class="img-fluid" alt="wearing-mask">
                </div>
            </div>
        </div>
    </section>

    <!-- Bootstrap Bundle with Popper -->
    <script src="js/bootstrap.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/jquery-ui.min.js"></script>
    <script type="text/javascript" src="js/popper.min.js"></script>
</body>

</html>