<?php
include_once("koneksi.php");
// Display selected user data based on id
// Getting id from url
$id = $_GET['id'];

// Fetech user data based on id
$con = mysqli_connect("localhost", "root", "", "eduvid");
$result = mysqli_query($con, "SELECT * FROM data_user WHERE id_user=$id ");


while ($row = mysqli_fetch_array($result)) {
  $nama_user = $row['nama_user'];
  $jk_user = $row['jk_user'];
  $tgl_user = $row['tgl_user'];
  $notelp_user = $row['notelp_user'];
  $email_user = $row['email_user'];
  $password_user = $row['password_user'];
  $role_user = $row['role_user'];
}
// Check if form is submitted for user update, then redirect to homepage after update
if (isset($_POST['Update'])) {
  $nama_user = $_POST['nama_user'];
  $jk_user = $_POST['jk_user'];
  $tgl_user = $_POST['tgl_user'];
  $notelp_user = $_POST['notelp_user'];
  $email_user = $_POST['email_user'];
  $password_user = $_POST['password_user'];
  $role_user = $_POST['role_user'];

  $query = "UPDATE data_user SET nama_user='$nama_user',jk_user='$jk_user', tgl_user='$tgl_user', notelp_user='$notelp_user', email_user='$email_user', password_user='$password_user', role_user='$role_user' WHERE id_user='$id'";

  $sql = mysqli_query($db, $query); // Eksekusi/ Jalankan query dari variabel $query

  if ($sql) { // Cek jika proses simpan ke database sukses atau tidak
    // Jika Sukses, Lakukan :
    header("Location: data-user.php?alert=berhasil"); // Redirectke halaman upload
  } else {
    // Jika Gagal, Lakukan :
    echo "Maaf, Terjadi kesalahan saat mencoba untuk menyimpan data ke database.";
    echo "<br><a href='data-covid.php?alert=kesalahan'>Kembali Ke Form</a>";
  }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <!-- Bootstrap CSS -->
  <link href="./css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous" />
  <!-- CSS Style -->
  <link rel="stylesheet" href="./css/style.css" />
  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.gstatic.com" />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet" />

  <title>Edit Data User</title>
</head>

<body>
  <div class="container-fluid">
    <div class="row">
      <!-- Menu -->
      <div class="col-3 text-center container-menu">
        <div>
          <!-- Logo Eduvid -->
          <img class="mt-4" src="./assets/img/logo-eduvid.svg" alt="Logo Eduvid">
          <!-- Wrapper menu -->
          <div class="px-4 mt-5">
            <!-- Menu Dashboard -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 menu" href="dashboard.php">
              <img class="img-menu" src="./assets/img/i-dashboard-gray.svg" alt="icon dashboard">
              <p class="my-auto ms-3 gray-color title-menu">Dashboard</p>
            </a>
            <!-- Menu Data Covid Active -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 menu" href="data-covid.php">
              <img class="img-menu" src="./assets/img/i-covid-gray.svg" alt="icon dashboard">
              <p class="my-auto ms-3 gray-color">Data Covid</p>
            </a>
            <!-- Menu User -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 menu selected" href="data-user.php">
              <img class="img-menu" src="./assets/img/i-user-white.svg" alt="icon dashboard">
              <p class="my-auto ms-3 gray-color title-menu-active">Data User</p>
            </a>
            <!-- Menu Kembali -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 to-home">
              <img class="img-menu" src="./assets/img/i-back-blue.svg" alt="icon dashboard">
              <p class="my-auto ms-3 gray-color title-menu" style="color: #0085FF;">Log Out</p>
            </a>
          </div>
        </div>
      </div>
      <!-- Content -->
      <div class="col white-color px-5">
        <!-- Title -->
        <h1 class="title mt-4">Edit Data User</h1>
        <div class="mt-4">
          <!-- Edit -->
          <hr class="divider" />
          <form class="container-form" action="" method="post">
            <!-- Nama -->
            <div class="mt-3">
              <label for="">Nama : </label><br>
              <input class="input-text mt-2" type="text" name="nama_user" id="nama_user" placeholder="Nama Kamu" value=<?php echo "'" . $nama_user . "'"; ?>>
            </div>
            <!-- Jenis Kelamin -->
            <div class="mt-3">
              <label for="">Jenis Kelamin : </label>
              <select class="form-select mt-2" name="jk_user" id="jk_user">
                <?php
                if (strcasecmp($jk_user, "laki-laki") == 0) {
                  echo "<option value='laki-laki' selected='true'> laki-laki </option>";
                  echo "<option value='perempuan'> perempuan </option>";
                }

                if (strcasecmp($jk_user, "perempuan") == 0) {
                  echo "<option value='laki-laki' > laki-laki </option>";
                  echo "<option value='perempuan' selected='true'> perempuan </option>";
                }

                ?>
              </select>
            </div>
            <!-- Tanggal Lahir -->
            <div class="mt-3">
              <label for="">Tanggal Lahir : </label><br>
              <input class="input-text mt-2" type="date" name="tgl_user" id="tgl_user" value=<?php echo "'" . $tgl_user . "'"; ?>>
            </div>
            <!-- Nomor Telepon -->
            <div class="mt-3">
              <label for="">Nomor Telepon : </label><br>
              <input class="input-text mt-2" type="tel" name="notelp_user" id="notelp_user" placeholder="Nomor Telepon" value=<?php echo "'" . $notelp_user . "'"; ?>>
            </div>
            <!-- Email -->
            <div class="mt-3">
              <label for="">Email : </label><br>
              <input class="input-text mt-2" type="tel" name="email_user" id="email_user" placeholder="Email" value=<?php echo "'" . $email_user . "'"; ?>>
            </div>
            <!-- Password -->
            <div class="mt-3">
              <label for="">Password : </label><br>
              <input class="input-text mt-2" type="tel" name="password_user" id="password_user" placeholder="Password" value=<?php echo "'" . $password_user . "'"; ?>>
            </div>
            <!-- Rules -->
            <div class="mt-3">
              <label for="">Role : </label>
              <select class="form-select mt-2" name="role_user" id="role_user">

                <?php

                if (strcasecmp($role_user, "Admin") == 0) {
                  echo "<option value='Admin' selected='true'> Admin </option>";
                  echo "<option value='Covid Ranger'> Covid Ranger </option>";
                }

                if (strcasecmp($role_user, "Covid Ranger") == 0) {
                  echo "<option value='Admin'> Admin </option>";
                  echo "<option value='Covid Ranger' selected='true'> Covid Ranger </option>";
                }


                ?>

              </select>
            </div>
            <button name="Update" value=Update class="btn-save mt-4">Save</button>
          </form>
          <script language="JavaScript" type="text/javascript">
            function Update(id) {
              if (confirm("Simpan Perubahan ?")) {
                window.location.href = 'edit-data-user.php?id=' + id;
              }
            }
          </script>


        </div>
      </div>
    </div>
  </div>

  <!-- Optional JavaScript; choose one of the two! -->

  <!-- Option 1: Bootstrap Bundle with Popper -->
  <script src="./js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous">
  </script>

  <!-- Option 2: Separate Popper and Bootstrap JS -->
  <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
    -->
</body>

</html>