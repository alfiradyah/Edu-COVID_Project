<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="./css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
  <!-- CSS Style -->
  <link rel="stylesheet" href="./css/style.css">
  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

  <title>🦠 Data Covid </title>
</head>

<body>
  <div class="container-fluid">
    <div class="row">
      <!-- fixed -->
      <div class="position-fixed top-0 start-0 col-3 text-center container-menu" style="z-index: 1;">
        <div>
          <!-- Logo Eduvid -->
          <img class="mt-4" src="./assets/img/logo-eduvid.svg" alt="Logo Eduvid">
          <!-- Wrapper menu -->
          <div class="px-4 mt-5">
            <!-- Menu Dashboard -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 menu" href="dashboard.php">
              <img class="img-menu" src="./assets/img/i-dashboard-gray.svg" alt="icon dashboard">
              <p class="my-auto ms-3 gray-color title-menu">Dashboard</p>
            </a>
            <!-- Menu Data Covid Active -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 menu selected">
              <img class="img-menu" src="./assets/img/i-covid-white.svg" alt="icon dashboard">
              <p class="my-auto ms-3 gray-color title-menu-active">Data Covid</p>
            </a>
            <!-- Menu User -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 menu" href="data-user.php">
              <img class="img-menu" src="./assets/img/i-user-gray.svg" alt="icon dashboard">
              <p class="my-auto ms-3 gray-color title-menu">Data User</p>
            </a>
            <!-- Menu Kembali -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 to-home">
              <img class="img-menu" src="./assets/img/i-back-blue.svg" alt="icon dashboard">
              <p class="my-auto ms-3 gray-color title-menu" style="color: #0085FF;">Log Out</p>
            </a>
          </div>
        </div>
      </div>
      <!-- Menu -->
      <div class="col-3 text-center container-menu">
        <div>
          <!-- Logo Eduvid -->
          <img class="mt-4" src="./assets/img/logo-eduvid.svg" alt="Logo Eduvid">
          <!-- Wrapper menu -->
          <div class="px-4 mt-5">
            <!-- Menu Dashboard -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 menu" href="dashboard.php">
              <img class="img-menu" src="./assets/img/i-dashboard-gray.svg" alt="icon dashboard">
              <p class="my-auto ms-3 gray-color title-menu">Dashboard</p>
            </a>
            <!-- Menu Data Covid Active -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 menu selected" href="data-covid.php">
              <img class="img-menu" src="./assets/img/i-covid-white.svg" alt="icon dashboard">
              <p class="my-auto ms-3 gray-color title-menu-active">Data Covid</p>
            </a>
            <!-- Menu User -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 menu" href="data-user.php">
              <img class="img-menu" src="./assets/img/i-user-gray.svg" alt="icon dashboard">
              <p class="my-auto ms-3 gray-color title-menu">Data User</p>
            </a>
            <!-- Menu Kembali -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 to-home">
              <img class="img-menu" src="./assets/img/i-back-blue.svg" alt="icon dashboard">
              <p class="my-auto ms-3 gray-color title-menu" style="color: #0085FF;">Log Out</p>
            </a>
          </div>
        </div>
      </div>
      <!-- Content -->
      <div class="col-9 white-color px-5">
        <!-- Title -->
        <h1 class="title mt-4">Data Covid 🦠</h1>
        <div class="mt-4">
          <!-- Card summary data covid -->
          <h5>Summary Data Covid</h5>
          <hr class="divider">
          <div class="mt-4 d-flex">

            <?php
            $con = mysqli_connect("localhost", "root", "", "eduvid");
            // Check connection
            if (mysqli_connect_errno()) {
              echo "Failed to connect to MySQL: " . mysqli_connect_error();
            }

            $result = mysqli_query($con, "SELECT * FROM data_covid");



            $count_covid = 0;
            $count_positif = 0;
            $count_sembuh = 0;
            $count_meninggal = 0;


            while ($row = mysqli_fetch_array($result)) {
              $status_pasien = $row['status_pasien'];
              $count_covid++;
              if (strcasecmp($status_pasien, "Positif") == 0) {
                $count_positif++;
              }

              if (strcasecmp($status_pasien, "Sembuh") == 0) {
                $count_sembuh++;
              }

              if (strcasecmp($status_pasien, "Meninggal") == 0) {
                $count_meninggal++;
              }
            }
            // Card Sembuh
            // Card Positif
            echo '<div class="card-summary ps-3 pe-5 pt-3 me-3">
                  <h6 class="title-card">Total Data Covid</h6>';
            echo " <p class='count-data' style='color: #0085FF;'>" .  $count_covid . "<span>kasus</span></p>";
            echo "</div>";

            // Card Positif
            echo "<div class='card-summary ps-3 pe-5 pt-3 me-3'>
                    <h6 class='title-card'>Kasus Positif</h6>";
            echo " <p class='count-data' style='color: #FF5C00;'>" .  $count_positif . "<span>kasus</span></p>";
            echo "</div>";

            // Card Sembuh
            echo "<div class='card-summary ps-3 pe-5 pt-3 me-3'>
                    <h6 class='title-card'>Kasus Sembuh</h6>";
            echo " <p class='count-data' style='color: #44A44E;'>" .  $count_sembuh . "<span>kasus</span></p>";
            echo "</div>";

            // Card Meninggal
            echo "<div class='card-summary ps-3 pe-5 pt-3 me-3'>
                    <h6 class='title-card'>Kasus Meninggal</h6>";
            echo " <p class='count-data' style='color: #E42E2E;'>" .  $count_meninggal . "<span>kasus</span></p>";
            echo "</div>";

            mysqli_close($con);
            ?>

            <!-- card positif -->
            <!-- <div class="card-summary ps-3 pe-5 pt-3">
              <h6 class="title-card">Kasus Positif</h6>
              <p class="count-data" style="color: #FF5C00;">103.233 <span>kasus</span></p>
            </div> -->
            <!-- card sembuh -->
            <!-- <div class="card-summary ps-3 pe-5 pt-3 ms-3">
              <h6 class="title-card">Kasus Sembuh</h6>
              <p class="count-data" style="color: #44A44E;">103.233 <span>kasus</span></p>
            </div> -->
            <!-- card meninggal -->
            <!-- <div class="card-summary ps-3 pe-5 pt-3 ms-3">
              <h6 class="title-card">Kasus Meninggal</h6>
              <p class="count-data" style="color: #E42E2E;">103.233 <span>kasus</span></p>
            </div>-->
          </div>
          <div class="mt-5 px-3 py-3 shadow rounded-3">
            <h5>Total Data Covid</h5>
            <hr class="divider" />
            <canvas id="chartCovid"></canvas>
          </div>
          <!-- data keseluruhan -->
          <div class="mt-5 d-flex justify-content-between align-items-center">
            <h5>Data Covid Keseluruhan</h5>




            <form class="container-search" action="data-covid.php" method="get">
              <input type="text" name="cari" class="input-search" id="" placeholder=<?php
                                                                                    if (isset($_GET['cari'])) {
                                                                                      $cari = $_GET['cari'];
                                                                                      echo "'Hasil pencarian : " . $cari . "'";
                                                                                    } else {
                                                                                      echo "'Cari'";
                                                                                    }
                                                                                    ?>>
              <input type="image" value="Cari" class="icon-search" src="assets/img/i-search-gray.svg" alt="">
            </form>



          </div>
          <hr class="divider">

          <?php
          $con = mysqli_connect("localhost", "root", "", "eduvid");
          // Check connection
          if (mysqli_connect_errno()) {
            echo "Failed to connect to MySQL: " . mysqli_connect_error();
          }

          if (isset($_GET['cari'])) {
            $cari = $_GET['cari'];
            $result = mysqli_query($con, "SELECT * FROM data_covid WHERE nama_pasien LIKE '%" . $cari . "%'");
          } else {
            $result = mysqli_query($con, "SELECT * FROM data_covid");
          }

          //$result = mysqli_query($con,"SELECT * FROM data_covid");

          echo "<table class='table table-hover'>
                  <thead>
                    <tr class='table-head'>
                      <th scope='col'>ID</th>
                      <th scope='col'>Time Stamp</th>
                      <th scope='col'>Nama</th>
                      <th scope='col'>Jenis Kelamin</th>
                      <th scope='col'>Tanggal lahir</th>
                      <th scope='col'>Nomor Telepon</th>
                      <th scope='col'>Alamat</th>
                      <th scope='col'>Status</th>
                      <th scope='col'>Action</th>
                    </tr>
                  </thead>
                  <tbody>";

          while ($row = mysqli_fetch_array($result)) {
            echo "<tr>";
            echo "<td>" . $row['id_pasien'] . "</td>";
            echo "<td>" . $row['timestamp_datacovid'] . "</td>";
            echo "<td>" . $row['nama_pasien'] . "</td>";
            echo "<td>" . $row['jk_pasien'] . "</td>";
            echo "<td>" . $row['tgl_pasien'] . "</td>";
            echo "<td>" . $row['notelp_pasien'] . "</td>";
            echo "<td>" . $row['alamat_pasien'] . "</td>";
            $status_pasien = $row['status_pasien'];
            if (strcasecmp($status_pasien, "Positif") == 0) {
              echo "<td> <div class='px-3 px-2 rounded-3 text-center' style='background-color: #FCE1D3; color: #FF792E;'> " . $row['status_pasien'] . "</div> </td>";
            }

            if (strcasecmp($status_pasien, "Sembuh") == 0) {
              echo "<td> <div class='px-3 px-2 rounded-3 text-center' style='background-color: #D6EAD9; color: #44A44E;'> " . $row['status_pasien'] . "</div> </td>";
            }

            if (strcasecmp($status_pasien, "Meninggal") == 0) {
              echo "<td> <div class='px-3 px-2 rounded-3 text-center' style='background-color: #D7D7D7; color: #818181;'> " . $row['status_pasien'] . "</div> </td>";
            }


            echo "<td align = 'center'> <a href='edit-data-covid.php?id=$row[id_pasien]' onclick = '' class='btn d-flex align-items-center justify-content-center btn-action rounded-3' style='background-color: #0085FF; color: #f0f0f0;'><img class='me-1' src='./assets/img/i-edit-white.svg' alt=''>Edit</a></td>";

            echo "<td align = 'center'> <a href= 'javascript:hapusData(" . $row['id_pasien'] . ")' onclick='return confirm('Yakin Hapus ?')' class='btn d-flex align-items-center justify-content-center btn-action rounded-3' style='background-color: #E42E2E; color: #f0f0f0;'><img class='me-1' src='./assets/img/i-delete-white.svg' alt=''>Hapus</a></td>";
            echo "</tr>";
          }
          echo "</tbody>
                  </table>";

          mysqli_close($con);
          ?>
          <script language="JavaScript" type="text/javascript">
            function hapusData(id) {
              if (confirm("Apakah anda yakin akan menghapus data ini?")) {
                window.location.href = 'hapus-pasien.php?id=' + id;
              }
            }
          </script>


          <hr class="divider">
        </div>
      </div>
    </div>
  </div>

  <!-- Optional JavaScript; choose one of the two! -->

  <!-- Option 1: Bootstrap Bundle with Popper -->
  <script src="./js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>


  <script src="https://cdn.jsdelivr.net/npm/chart.js@3.3.2/dist/chart.min.js"></script>

  <script>
    showTotalUserChart();

    function showTotalUserChart() {
      // Setup
      const labels = [
        'Jan',
        'Feb',
        'Mar',
        'Apr',
        'May',
        'Jun',
        'Jul',
        'Agu',
        'Sep',
        'Okt',
        'Nov',
        'Des'
      ];
      const data = {
        labels: labels,
        datasets: [{
            label: 'Kasus Positif',
            backgroundColor: 'rgb(255, 121, 46)',
            borderColor: 'rgb(255, 121, 46)',
            data: [10, 18, 34, 37, 52, 68, 70, 72, 84, 90, 100, 152],
          },
          {
            label: 'Kasus Sembuh',
            backgroundColor: 'rgb(68, 164, 78)',
            borderColor: 'rgb(68, 164, 78)',
            data: [3, 6, 14, 18, 22, 28, 30, 40, 44, 49, 60, 72],
          },
          {
            label: 'Kasus Meninggal',
            backgroundColor: 'rgb(228, 46, 46)',
            borderColor: 'rgb(228, 46, 46)',
            data: [1, 4, 5, 7, 12, 13, 15, 16, 20, 23, 22, 32],
          }
        ]
      };
      // Config
      const config = {
        type: 'line',
        data,
        options: {}
      };
      var totalUserChart = new Chart(
        document.getElementById('chartCovid'),
        config
      );
    }
  </script>
  <!-- Option 2: Separate Popper and Bootstrap JS -->
  <!--
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
  -->
</body>

</html>