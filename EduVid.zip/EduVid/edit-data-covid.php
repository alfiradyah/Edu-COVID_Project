<?php
include_once("koneksi.php");
// Display selected user data based on id
// Getting id from url
$id = $_GET['id'];

// Fetech user data based on id
$con = mysqli_connect("localhost", "root", "", "eduvid");
$result = mysqli_query($con, "SELECT * FROM data_covid WHERE id_pasien=$id ");


while ($row = mysqli_fetch_array($result)) {
  $nama_pasien = $row['nama_pasien'];
  $jk_pasien = $row['jk_pasien'];
  $tgl_pasien = $row['tgl_pasien'];
  $notelp_pasien = $row['notelp_pasien'];
  $alamat_pasien = $row['alamat_pasien'];
  $status_pasien = $row['status_pasien'];
}
// Check if form is submitted for user update, then redirect to homepage after update
if (isset($_POST['Update'])) {
  $nama_pasien = $_POST['nama_pasien'];
  $jk_pasien = $_POST['jk_pasien'];
  $tgl_pasien = $_POST['tgl_pasien'];
  $notelp_pasien = $_POST['notelp_pasien'];
  $alamat_pasien = $_POST['alamat_pasien'];
  $status_pasien = $_POST['status_pasien'];

  $query = "UPDATE data_covid SET nama_pasien='$nama_pasien',jk_pasien='$jk_pasien', tgl_pasien='$tgl_pasien', notelp_pasien='$notelp_pasien', alamat_pasien='$alamat_pasien', status_pasien='$status_pasien' WHERE id_pasien='$id'";

  $sql = mysqli_query($db, $query); // Eksekusi/ Jalankan query dari variabel $query

  if ($sql) { // Cek jika proses simpan ke database sukses atau tidak
    // Jika Sukses, Lakukan :
    header("Location: data-covid.php?alert=berhasil"); // Redirectke halaman upload
  } else {
    // Jika Gagal, Lakukan :
    echo "Maaf, Terjadi kesalahan saat mencoba untuk menyimpan data ke database.";
    echo "<br><a href='data-covid.php?alert=kesalahan'>Kembali Ke Form</a>";
  }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <!-- Bootstrap CSS -->
  <link href="./css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous" />
  <!-- CSS Style -->
  <link rel="stylesheet" href="./css/style.css" />
  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.gstatic.com" />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet" />

  <title>Edit Data Covid</title>
</head>

<body>
  <div class="container-fluid">
    <div class="row">
      <!-- Menu -->
      <div class="col-3 text-center container-menu">
        <div>
          <!-- Logo Eduvid -->
          <img class="mt-4" src="./assets/img/logo-eduvid.svg" alt="Logo Eduvid">
          <!-- Wrapper menu -->
          <div class="px-4 mt-5">
            <!-- Menu Dashboard -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 menu" href="dashboard.php">
              <img class="img-menu" src="./assets/img/i-dashboard-gray.svg" alt="icon dashboard">
              <p class="my-auto ms-3 gray-color title-menu">Dashboard</p>
            </a>
            <!-- Menu Data Covid Active -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 menu selected" href="data-covid.php">
              <img class="img-menu" src="./assets/img/i-covid-white.svg" alt="icon dashboard">
              <p class="my-auto ms-3 gray-color title-menu-active">Data Covid</p>
            </a>
            <!-- Menu User -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 menu" href="data-user.php">
              <img class="img-menu" src="./assets/img/i-user-gray.svg" alt="icon dashboard">
              <p class="my-auto ms-3 gray-color title-menu">Data User</p>
            </a>
            <!-- Menu Kembali -->
            <a class="px-4 py-2 mt-2 d-flex rounded-3 to-home">
              <img class="img-menu" src="./assets/img/i-back-blue.svg" alt="icon dashboard">
              <p class="my-auto ms-3 gray-color title-menu" style="color: #0085FF;">Log Out</p>
            </a>
          </div>
        </div>
      </div>
      <!-- Content -->
      <div class="col white-color px-5">
        <!-- Title -->
        <h1 class="title mt-4">Edit Data Covid </h1>
        <div class="mt-4">
          <!-- Edit -->
          <hr class="divider" />
          <form class="container-form" action="" method="post">
            <!-- Nama -->
            <div class="mt-3">
              <label for="">Nama : </label><br>
              <input class="input-text mt-2" type="text" name="nama_pasien" id="nama_pasien" placeholder="Nama Kamu" value=<?php echo "'" . $nama_pasien . "'"; ?>>
            </div>
            <!-- Jenis Kelamin -->
            <div class="mt-3">
              <label for="">Jenis Kelamin : </label>
              <select class="form-select mt-2" name="jk_pasien" id="jk_pasien">
                <?php
                if (strcasecmp($jk_pasien, "laki-laki") == 0) {
                  echo "<option value='laki-laki' selected='true'> laki-laki </option>";
                  echo "<option value='perempuan'> perempuan </option>";
                }

                if (strcasecmp($jk_pasien, "perempuan") == 0) {
                  echo "<option value='laki-laki' > laki-laki </option>";
                  echo "<option value='perempuan' selected='true'> perempuan </option>";
                }

                ?>
              </select>

            </div>
            <!-- Tanggal Lahir -->
            <div class="mt-3">
              <label for="">Tanggal Lahir : </label><br>
              <input class="input-text mt-2" type="date" name="tgl_pasien" id="tgl_pasien" value=<?php echo "'" . $tgl_pasien . "'"; ?>>
            </div>
            <!-- Nomor Telepon -->
            <div class="mt-3">
              <label for="">Nomor Telepon : </label><br>
              <input class="input-text mt-2" type="tel" name="notelp_pasien" id="notelp_pasien" placeholder="Nomor Telepon" value=<?php echo "'" . $notelp_pasien . "'"; ?>>
            </div>
            <!-- Email -->
            <div class="mt-3">
              <label for="">Alamat : </label><br>
              <textarea class="input-text mt-2" name="alamat_pasien" id="alamat_pasien" cols="30" rows="3" placeholder="Alamat" value=<?php echo "'" . $alamat_pasien . "'"; ?>><?php echo $alamat_pasien; ?></textarea>
            </div>
            <!-- Rules -->
            <div class="mt-3">
              <label for="">Status : </label>
              <select class="form-select mt-2" name="status_pasien" id="status_pasien">

                <?php

                if (strcasecmp($status_pasien, "Positif") == 0) {
                  echo "<option value='Positif' selected='true'> Positif </option>";
                  echo "<option value='Sembuh'> Sembuh </option>";
                  echo "<option value='Meninggal'> Meninggal </option>";
                }

                if (strcasecmp($status_pasien, "Sembuh") == 0) {
                  echo "<option value='Positif'> Positif </option>";
                  echo "<option value='Sembuh' selected='true'> Sembuh </option>";
                  echo "<option value='Meninggal'> Meninggal </option>";
                }

                if (strcasecmp($status_pasien, "Meninggal") == 0) {
                  echo "<option value='Positif'> Positif </option>";
                  echo "<option value='Sembuh'> Sembuh </option>";
                  echo "<option value='Meninggal' selected='true'> Meninggal </option>";
                }

                ?>

              </select>
            </div>
            <button name="Update" value=Update class="btn-save mt-4">Save</button>
          </form>
          <script language="JavaScript" type="text/javascript">
            function Update(id) {
              if (confirm("Simpan Perubahan ?")) {
                window.location.href = 'edit-data-covid.php?id=' + id;
              }
            }
          </script>
        </div>
      </div>
    </div>
  </div>

  <!-- Optional JavaScript; choose one of the two! -->

  <!-- Option 1: Bootstrap Bundle with Popper -->
  <script src="./js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous">
  </script>

  <!-- Option 2: Separate Popper and Bootstrap JS -->
  <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
    -->
</body>

</html>