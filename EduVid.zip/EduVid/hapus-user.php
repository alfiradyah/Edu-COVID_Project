<?php
// include database connection file
include_once("koneksi.php");

// Get id from URL to delete that user
$id = $_GET['id'];

$sql = mysqli_query($db, "SELECT * FROM data_user WHERE id_user=$id");
$data = $sql->fetch_assoc();
$id_user = $data['id_user'];
$nama_user = $data['nama_user'];


// Delete user row from table based on given id
$result = mysqli_query($db, "DELETE FROM data_user WHERE id_user=$id");
  if($result){
  	echo "<script>alert($id_user)</script>";
    echo "<script>alert($nama_user)</script>";
    header("Location:data-user.php?alert=berhasil");
  }else{
    echo "Maaf, Terjadi kesalahan saat menghapus user di database.";
    echo "<br><a href='edit-data-user.php?alert=kesalahan'>Kembali Ke Data User</a>";
  }


?>