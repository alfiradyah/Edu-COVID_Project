<?php
include 'koneksi.php';

error_reporting(0);

//Kondisi match
if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);
    $cpassword = md5($_POST['cpassword']);

    //kondisi password dan confirm password
    if ($password == $cpassword) {
        $sql = "SELECT * FROM users WHERE email='$email'";
        $result = mysqli_query($db, $sql);

        //kondisi kalo udh ada datanya
        if (!$result->num_rows > 0) {
            //kalo sesuai = masuk ke database
            $sql = "INSERT INTO users (username, email, password)
                    VALUES ('$username', '$email', '$password')";
            $result = mysqli_query($db, $sql);

            //kondisi udh klik regist
            if ($result) {
                echo "<script>alert('Cie dah punya akun ;p')</script>";
                //biar formnya kosong lagi
                $username = "";
                $email = "";
                $_POST['password'] = "";
                $_POST['cpassword'] = "";
                header("Location: login.php");
            } else {
                echo "<script>alert('O'Owww! Ada yang salah niyy!')</script>";
            }
        } else {
            echo "<script>alert('Woops datanya sudah ada ni bro :/')</script>";
        }
    } else {
        // echo "<script>alert('Passwordnya nda sama ni bun :/')</script>";

    }
}
?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

    <link href="css/log-reg.css" type="text/css" rel="stylesheet">
    <title>Regist Form EduCOVID</title>
</head>

<body>
    <section class="login py-5 bg-light">
        <div class="container">
            <div class="row g-0">
                <div class="col-lg-7 text-center py-5">
                    <h1>Welcome to Edu-COVID</h1>
                    <h4 class="py-3">Please Fill the Form Below to Have an Account</h4>
                    <form action="" method="POST">
                        <!-- <div class="form-row py-2">
                            <div class="selectWrapper">
                                <select name="user" class="selectBox" required="">
                                    <option value="">-- Who Are You? --</option>
                                    <option value="admin">Admin</option>
                                    <option value="doctor">Covid Ranger</option>
                                </select>
                            </div>
                        </div> -->
                        <div class="form-row py-2">
                            <div class="offset-1 col-lg-10">
                                <input type="text" name="username" placeholder="Username" class="input" value="<?php echo $username; ?>" required>
                            </div>
                        </div>
                        <div class="form-row py-2">
                            <div class="offset-1 col-lg-10">
                                <input type="email" name="email" placeholder="Email Address" class="input" value="<?php echo $email; ?>" required>
                            </div>
                        </div>
                        <div class="form-row py-2">
                            <div class="offset-1 col-lg-10">
                                <input type="password" name="password" placeholder="Password" class="input" value="<?php echo $_POST['password']; ?>" required>
                            </div>
                        </div>
                        <div class="form-row py-2">
                            <div class="offset-1 col-lg-10">
                                <input type="password" name="cpassword" placeholder="Confirm Password" class="input" value="<?php echo $_POST['cpassword']; ?>" required>
                            </div>
                        </div>
                        <button class="btn" name="submit">Regist</button>
                        <div class="py-2">
                            <p>Already have an account? <a href="login.php">Login Here</a></p>
                        </div>
                    </form>
                </div>
                <div class="col-lg-5">
                    <img src="img/wearing-mask.png" class="img-fluid" alt="wearing-mask">
                </div>
            </div>
        </div>
    </section>

    <!-- Bootstrap Bundle with Popper -->
    <script src="js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
</body>

</html>